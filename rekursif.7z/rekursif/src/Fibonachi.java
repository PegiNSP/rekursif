public class Fibonachi {
    public static int fibonacci(int n) {
        if (n <= 1) {
            return n;
        } else {
            return fibonacci(n - 1) + fibonacci(n - 2);
        }
    }

    public static void main(String[] args) {
        int angka = 7;
        System.out.println("Deret Fibonacci ke-" + angka + " adalah: ");
        for (int i = 0; i < angka; i++) {
            System.out.print(fibonacci(i) + " ");
        }
    }
}

