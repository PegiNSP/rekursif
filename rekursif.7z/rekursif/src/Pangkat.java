public class Pangkat {
    public static int pangkat(int x, int y) {
        if (y == 0) {
            return 1;
        } else {
            return x * pangkat(x, y - 1);
        }
    }

    public static void main(String[] args) {
        int angka = 2;
        int pangkat = 4;
        int hasil = pangkat(angka, pangkat);
        System.out.println(angka + " pangkat " + pangkat + " adalah: " + hasil);
    } 
}
